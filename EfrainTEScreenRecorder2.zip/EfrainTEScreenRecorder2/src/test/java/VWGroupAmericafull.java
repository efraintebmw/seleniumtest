//package TestMex;
/***********************
 * Flow Happy path
 * VW - Privacy Portal
 * 
 * Read excel and apply the # of rows
 * Autor Efrain Trejo Escoto
 * last execute 19/05/2021
 * last change 28/05/2021
************************/
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import java.io.File;
import java.io.FileInputStream;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


public class VWGroupAmericafull {

	static ExtentTest test;
	static ExtentReports report;

	@BeforeClass
	public static void startTest()
	{
		report = new ExtentReports(System.getProperty("user.dir")+"/EfraintTestResultsVWGA.html");
		test = report.startTest("DemoEfrainT to Group America");
	}
	
	static String Sdata01=null;
	static String Sdata02=null;
	private XSSFWorkbook wb;
	
	@Test

	public void extentReportsDemo() throws Exception
	{
		MyScreenRecorder.startRecording("EfrainT to Group America");
		//la fecha se�a 1998/11/2 07:10:00 (Noviembre 2 de 1998)
				Calendar cal = Calendar.getInstance();
				cal.roll(Calendar.MINUTE, 70);
				cal.roll(Calendar.DATE, 22);
				
				System.out.println(cal.getTime());
				
				// TODO Auto-generated method stub (abrir excel)
				File src=new File("/Users/efraintrejo/Desktop/qatesting2/workspace/EfrainTEScreenRecorder2/TestData.xlsx");
				FileInputStream fis=new FileInputStream(src);
				wb = new XSSFWorkbook(fis);
				XSSFSheet sheet1=wb.getSheetAt(0);
				
				//open tab
				int rowcount=sheet1.getLastRowNum();
				//lee los renglones totales
				System.out.println("Total of Rows is "+rowcount);
				
				
				
		System.setProperty("webdriver.chrome.driver", "/Users/efraintrejo/Desktop/efrainfo/chromedriver90");
		WebDriver driver = new ChromeDriver();
		driver.get("https://d2482eeh5wnyn0.cloudfront.net/"); 

		//iniciate Browser y Maximizar
		driver.manage().window().maximize(); 
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		int num=1;
		int j=0;    
		for(int i = 0; i <= rowcount; i = i++)
		{

		
		//-----Section | Home ----
		
		if(driver.getTitle().equals("VW - Privacy Portal"))
		{
			test.log(LogStatus.PASS, "Navigated in the specified URL VW - Privacy Portal");
			System.out.println("Navigated in the specified URL VW - Privacy Portal");
		}
		else
		{
			test.log(LogStatus.FAIL, "Test Failed to Navigated in the specified URL VW - Privacy Portal");
			System.out.println("Test Failed to Navigated in the specified URL VW - Privacy Portal");
		}

		//Screen
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile, new File("/Users/efraintrejo/Desktop/qatesting2/workspace/EfrainTEScreenRecorder2/screenshots/image"+num+".png"));
		test.log(LogStatus.INFO, "Screenshot-> Navigated in the specified URL VW - Privacy Portal" + test.addScreenCapture(System.getProperty("user.dir")+"/screenshots/image" +num+".png"));
		num++;

		//----Happy path-----
		
		//1. In which state are you currently a resident?
		//*[@id=\"California\"]  | //*[@id=\"root\"]/div/div[2]/div/div[5]/div[2]/div[1]/div[2]/div[1]/div/div/label/span
		//*[@id="Another_State"] | //*[@id=\"root\"]/div/div[2]/div/div[5]/div[2]/div[1]/div[2]/div[2]/div/div/label/span
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[5]/div[2]/div[1]/div[2]/div[1]/div/div/label/span")).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		test.log(LogStatus.PASS, "in 1. resident? Select California ");
		System.out.println("in 1. resident? Select California ");
		
		//2. Are you completing this CCPA form on behalf of yourself or someone else?
		//*[@id="I_am_completing_this_form_for_myself"]       | //*[@id="root"]/div/div[2]/div/div[6]/div/div[1]/div[2]/div[1]/div/div/label/span
		//*[@id="I_am_completing_this_form_for_someone_else"] | //*[@id="root"]/div/div[2]/div/div[6]/div/div[1]/div[2]/div[2]/div/div/label/span
		//*[@id="I_am_completing_this_form_for_a_Household"]  | //*[@id="root"]/div/div[2]/div/div[6]/div/div[1]/div[2]/div[3]/div/div/label/span
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[6]/div/div[1]/div[2]/div[1]/div/div/label/span")).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		test.log(LogStatus.PASS, "2. yourself or someone else?, Select I_am_completing_this_form_for_myself");
		System.out.println("2. yourself or someone else?, Selected I_am_completing_this_form_for_myself");
		
		//scrolldown
		 JavascriptExecutor js = (JavascriptExecutor) driver;
	        // This  will scroll down the page by  50 pixel vertical		
	        js.executeScript("window.scrollBy(0,100)");
		
		//3. Are you completing this CCPA form as, or on behalf of, a Bentley Motors, Inc. consumer?
		//*[@id="Yes"] | //*[@id="root"]/div/div[2]/div/div[7]/div/div[1]/div[2]/div[1]/div/div/label/span
		//*[@id="No"]  | //*[@id="root"]/div/div[2]/div/div[7]/div/div[1]/div[2]/div[2]/div/div/label/span
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[7]/div/div[1]/div[2]/div[1]/div/div/label/span")).click();
		test.log(LogStatus.PASS, "3. Bentley Motors, Inc. consumer?, selected Yes");
		System.out.println("3. Bentley Motors, Inc. consumer?, selected Yes");
		//Screen
		File scrFile1 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile1, new File("/Users/efraintrejo/Desktop/qatesting2/workspace/EfrainTEScreenRecorder2/screenshots/image"+num+".png"));
		test.log(LogStatus.INFO, "Screenshot-> cuestions" + test.addScreenCapture(System.getProperty("user.dir")+"/screenshots/image" +num+".png"));
		num++;
		
	        // This  will scroll down the page by  500 pixel vertical		
	        js.executeScript("window.scrollBy(0,200)");
	        
		//Continue Button
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[8]/div/button")).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		test.log(LogStatus.PASS, "Continue Button");
		System.out.println("Continue Button");

		
		//3. California Consumers have the following rights under the CCPA: Please select one request.
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[3]/div/div/div[3]/div/div/div")).click();
		test.log(LogStatus.PASS, "Click in Access My Personal Information");
		System.out.println("Click in Access My Personal Information");
		//secreen
		File scrFile2 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile2, new File("/Users/efraintrejo/Desktop/qatesting2/workspace/EfrainTEScreenRecorder2/screenshots/image"+num+".png"));
		test.log(LogStatus.INFO, "Screenshot-> select one request" + test.addScreenCapture(System.getProperty("user.dir")+"/screenshots/image" +num+".png"));
		num++;
		
		//Continue Button
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[5]/div/button")).click();
		test.log(LogStatus.PASS, "Continue Button");
		System.out.println("Continue Button");

			
		
		//4. We will need some information from you in order to process your request.
		//Specific Pieces Report | //*[@id="root"]/div/div[2]/div/div[1]/div[2]/div[2]/div/div/div/label/span
		//Categories Report      | //*[@id="root"]/div/div[2]/div/div[1]/div[2]/div[1]/div/div/div/label/span
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[1]/div[2]/div[2]/div/div/div/label/span")).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		test.log(LogStatus.PASS, "4. process your request. , selected Specific Pieces Report");
		System.out.println("4. process your request., selected Specific Pieces Report");
		//Screen
		File scrFile3 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile3, new File("/Users/efraintrejo/Desktop/qatesting2/workspace/EfrainTEScreenRecorder2/screenshots/image"+num+".png"));
		test.log(LogStatus.INFO, "Screenshot-> Some information" + test.addScreenCapture(System.getProperty("user.dir")+"/screenshots/image" +num+".png"));
		num++;

		//-----Data : First Name, Medial....----

		//abrir celda especifica renglon, columna
		String data01=sheet1.getRow(i).getCell(j).getStringCellValue();
		Sdata01=data01;
		
		//Fisrt Name
		driver.findElement(By.xpath("//*[@id=\"firstName\"]")).sendKeys(data01); 
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		System.out.println("efron");
		test.log(LogStatus.PASS, "Enter First Name");
		System.out.println("Enter First Name");
		
		j++;
		String data02=sheet1.getRow(i).getCell(j).getStringCellValue();
		Sdata02=data02;
		//Last Name
		driver.findElement(By.xpath("//*[@id=\"lastName\"]")).sendKeys(data02); 
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		test.log(LogStatus.PASS, "Enter Last Name");
		System.out.println("Enter Last Name");
		j--;
		//date of bird
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[1]/div[7]/div/div/form/div/div/div/div/input[2]")).sendKeys("01"); 
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[1]/div[7]/div/div/form/div/div/div/div/input[3]")).sendKeys("01");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[1]/div[7]/div/div/form/div/div/div/div/input[4]")).sendKeys("1998");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		test.log(LogStatus.PASS, "Enter Date to Bird");
		System.out.println("Enter Date to Bird");
		//email
		driver.findElement(By.xpath("//*[@id=\"emailAddress\"]")).sendKeys(data01+data02+num+"@qa.us"); 
		test.log(LogStatus.PASS, "Enter Email");
		System.out.println("Enter Email");
		//email
		driver.findElement(By.xpath("//*[@id=\"reEnterEmailAddress\"]")).sendKeys(data01+data02+num+"@qa.us"); 
		test.log(LogStatus.PASS, "Re-Enter Email");
		System.out.println("Re-nter Email");
		//Phone Number
		driver.findElement(By.xpath("//*[@id=\"phone\"]")).sendKeys("5623551916"); 
		test.log(LogStatus.PASS, "Enter Phone Number");
		System.out.println("Enter Phone Number");
		//SSN Number
		driver.findElement(By.xpath("//*[@id=\"ssn\"]")).sendKeys("987654325"); 
		test.log(LogStatus.PASS, "Enter SSN Number");
		System.out.println("Enter SSN Number");
		//VIN Number
		driver.findElement(By.xpath("//*[@id=\"vin\"]")).sendKeys("2HNYD18202H501322"); 
		test.log(LogStatus.PASS, "Enter VIN Number");
		System.out.println("Enter VIN Number");
		//Screen
		File scrFile4 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile4, new File("/Users/efraintrejo/Desktop/qatesting2/workspace/EfrainTEScreenRecorder2/screenshots/image"+num+".png"));
		test.log(LogStatus.INFO, "Screenshot-> Enter Data" + test.addScreenCapture(System.getProperty("user.dir")+"/screenshots/image" +num+".png"));
		num++;
		
		//Continue Button
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[1]/div[14]/div/button")).click();
		test.log(LogStatus.PASS, "Continue Button");
		System.out.println("Continue Button");
		
		//5. What is your current 
		//Screen
		File scrFile5 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile5, new File("/Users/efraintrejo/Desktop/qatesting2/workspace/EfrainTEScreenRecorder2/screenshots/image"+num+".png"));
		test.log(LogStatus.INFO, "Screenshot-> Mailing address?" + test.addScreenCapture(System.getProperty("user.dir")+"/screenshots/image" +num+".png"));
		num++;
		
		//Address Line 1
		driver.findElement(By.xpath("//*[@id=\"addressLine1\"]")).sendKeys("Berveli Hill Street"); 
		test.log(LogStatus.PASS, "Enter Address Line 1");
		System.out.println("Enter Address Line 1");
		//Address Line 2
		driver.findElement(By.xpath("//*[@id=\"addressLine2\"]")).sendKeys("blvd. 23 Bowldingpark"); 
		test.log(LogStatus.PASS, "Enter Address Line 2");
		System.out.println("Enter Address Line 2");
		//city
		driver.findElement(By.xpath("//*[@id=\"city\"]")).sendKeys("Pasadena"); 
		test.log(LogStatus.PASS, "Enter City");
		System.out.println("Enter City");
		//State
		driver.findElement(By.xpath("//*[@id=\"state\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"state\"]/option[7]")).click();
		test.log(LogStatus.PASS, "Select State");
		System.out.println("Select State");
		//ZIP
		driver.findElement(By.xpath("//*[@id=\"postalCode\"]")).sendKeys("90210"); 
		test.log(LogStatus.PASS, "Enter ZIP");
		System.out.println("Enter ZIP");
		//I agree with the Terms and Conditions
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[1]/div/div/div[8]/div/div/div/div/label/span[1]")).click();
		test.log(LogStatus.PASS, "Click on I agree with the Terms and Conditions");
		System.out.println("Click on I agree with the Terms and Conditions");
		//Screen
		File scrFile6 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile6, new File("/Users/efraintrejo/Desktop/qatesting2/workspace/EfrainTEScreenRecorder2/screenshots/image"+num+".png"));
		test.log(LogStatus.INFO, "Screenshot-> Mailing address?" + test.addScreenCapture(System.getProperty("user.dir")+"/screenshots/image" +num+".png"));
		num++;
		
		//Continue Button
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[2]/div/button")).click();
		test.log(LogStatus.PASS, "Continue Button");
		System.out.println("Continue Button");
		
		//We could not locate the address you entered, please review and re-enter your address.
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[4]/div/div/div[2]/div/div[2]/div/div/label/span")).click();
		test.log(LogStatus.PASS, "Click on Use the address entered");
		System.out.println("Click on Use the address entered");
		//Screen
		File scrFile7 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile7, new File("/Users/efraintrejo/Desktop/qatesting2/workspace/EfrainTEScreenRecorder2/screenshots/image"+num+".png"));
		test.log(LogStatus.INFO, "Screenshot-> re-enter your address" + test.addScreenCapture(System.getProperty("user.dir")+"/screenshots/image" +num+".png"));
		num++;
		
		//Continue Button
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"continue-button\"]/button")).click();
		test.log(LogStatus.PASS, "Continue Button");
		System.out.println("Continue Button");
		
		//Submit Button
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[2]/div/button")).click();
		test.log(LogStatus.PASS, "Submit Button");
		System.out.println("Submit Button");
		
		//PIN Number
		driver.findElement(By.xpath("//*[@id=\"pinNumber\"]")).sendKeys("1234"); 
		test.log(LogStatus.PASS, "Enter PIN");
		System.out.println("Enter PIN");
		//PIN Number
		driver.findElement(By.xpath("//*[@id=\"reEnterPinNumber\"]")).sendKeys("1234"); 
		test.log(LogStatus.PASS, "Re-Enter PIN");
		System.out.println("Re-Enter PIN");
		//Screen
		File scrFile8 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile8, new File("/Users/efraintrejo/Desktop/qatesting2/workspace/EfrainTEScreenRecorder2/screenshots/image"+num+".png"));
		test.log(LogStatus.INFO, "Screenshot-> PIN Number" + test.addScreenCapture(System.getProperty("user.dir")+"/screenshots/image" +num+".png"));
		num++;
		
		//Submit Button
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[1]/div[5]/div/button")).click();
		test.log(LogStatus.PASS, "Submit Button");
		System.out.println("Submit Button");
		//Screen
		File scrFile9 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile9, new File("/Users/efraintrejo/Desktop/qatesting2/workspace/EfrainTEScreenRecorder2/screenshots/image"+num+".png"));
		test.log(LogStatus.INFO, "Screenshot-> Submit Button" + test.addScreenCapture(System.getProperty("user.dir")+"/screenshots/image" +num+".png"));
		num++;
		
		//Submit Another Request
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[4]/div/button")).click();
		test.log(LogStatus.PASS, "Another Request");
		System.out.println("Another Request");
		
		test.log(LogStatus.PASS, "Finish the flow for "+data01+" "+data02);
		System.out.println("Finish the flow for "+data01+" "+data02);
		
		i++;
		} //end of Cicle for
		
		//browser close
		driver.close();
		//driver quit
		driver.quit();
		Thread.sleep(1000);
		MyScreenRecorder.stopRecording();
		
	}

	@AfterClass
	public static void endTest()
	{
		report.endTest(test);
		report.flush();
	}


}
